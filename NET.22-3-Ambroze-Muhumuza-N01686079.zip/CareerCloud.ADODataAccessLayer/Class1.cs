﻿namespace CareerCloud.ADODataAccessLayer
{
    public class Class1
    {

    }
}
