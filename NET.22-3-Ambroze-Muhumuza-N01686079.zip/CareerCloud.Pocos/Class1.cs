﻿namespace CareerCloud.Pocos
{
    public class Class1
    {

    }
}
