﻿namespace EntityFrameworkDataAccess
{
    public class Class1
    {

    }
}
