﻿namespace CareerCloud.DataAccessLayer
{
    public class Class1
    {

    }
}
