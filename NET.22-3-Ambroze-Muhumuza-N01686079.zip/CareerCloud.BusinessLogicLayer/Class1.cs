﻿namespace CareerCloud.BusinessLogicLayer
{
	public class Class1
	{

	}
}
